
SMODS.Seal {
    key = 'toad',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            emult0 = 1.1
        }
    },
    badge_colour = HEX('32CD32'),
    loc_txt = {
        name = 'Toad',
        label = 'Toad',
        text = {
            [1] = '{X:mult,C:white}^1.1{C:red} Mult{}'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    sound = { sound = "slice1", per = 1.2, vol = 0.4 },
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                e_mult = 1.1
            }
        end
    end
}