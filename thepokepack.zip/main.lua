SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/bluefairy.lua"))()
    assert(SMODS.load_file("jokers/strongfairy.lua"))()
    assert(SMODS.load_file("jokers/abookpropertyofbusyfairy.lua"))()
    assert(SMODS.load_file("jokers/merryfairyjoker.lua"))()
    assert(SMODS.load_file("jokers/fairydummy.lua"))()
    assert(SMODS.load_file("jokers/orbofwitch.lua"))()
    assert(SMODS.load_file("jokers/anglerfairy.lua"))()
    assert(SMODS.load_file("jokers/matra.lua"))()
    assert(SMODS.load_file("jokers/greentoad.lua"))()
    assert(SMODS.load_file("jokers/balltoad.lua"))()
    assert(SMODS.load_file("jokers/mspaint.lua"))()
    assert(SMODS.load_file("jokers/ohcrap.lua"))()
end
-- load the seals
if true then
    assert(SMODS.load_file("seals/toad.lua"))()
end

-- load the decks
if true then
    assert(SMODS.load_file("decks/wee_red_deck.lua"))()
end



assert(SMODS.load_file("rarities.lua"))()

SMODS.ObjectType({
    key = "thepokep_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "thepokep_thepokep_jokers",
    cards = {
        ["j_thepokep_bluefairy"] = true,
        ["j_thepokep_strongfairy"] = true,
        ["j_thepokep_abookpropertyofbusyfairy"] = true,
        ["j_thepokep_merryfairyjoker"] = true,
        ["j_thepokep_fairydummy"] = true,
        ["j_thepokep_orbofwitch"] = true,
        ["j_thepokep_anglerfairy"] = true,
        ["j_thepokep_matra"] = true,
        ["j_thepokep_greentoad"] = true,
        ["j_thepokep_balltoad"] = true,
        ["j_thepokep_mspaint"] = true
    },
})

SMODS.ObjectType({
    key = "thepokep_poke",
    cards = {
        ["j_thepokep_bluefairy"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end