SMODS.Rarity {
    key = "fairy",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.4,
    badge_colour = HEX('50e3c2'),
    loc_txt = {
        name = "Fairy"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "toad",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.4,
    badge_colour = HEX('28990b'),
    loc_txt = {
        name = "Toad"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "oo",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "O_O"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}