
SMODS.Joker{ --Angler Fairy
    key = "anglerfairy",
    config = {
        extra = {
            cardsindeck = 0
        }
    },
    loc_txt = {
        ['name'] = 'Angler Fairy',
        ['text'] = {
            [1] = 'Fishes up ALL CARDS FROM THE DECK when drawing hands.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "thepokep_fairy",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["thepokep_thepokep_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(#(G.deck and G.deck.cards or {}) or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.hand_drawn  then
            if G.hand and #G.hand.cards > 0 then
                SMODS.draw_cards(#(G.deck and G.deck.cards or {}))
            end
            return {
                message = "+"..tostring(#(G.deck and G.deck.cards or {})).." Cards Drawn"
            }
        end
    end
}