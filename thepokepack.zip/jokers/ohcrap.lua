
SMODS.Joker{ --oh crap
    key = "ohcrap",
    config = {
        extra = {
            dollars0 = 0,
            hands0 = 1,
            discards0 = 0,
            play_size0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'oh crap',
        ['text'] = {
            [1] = 'you are so {C:red}fucked{}.'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "thepokep_oo",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = false,
    discovered = false,
    atlas = 'CustomJokers',
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if #G.jokers.cards > 0 then
                for _, joker in ipairs(G.jokers.cards) do
                    joker:flip()
                end
            end
            if #G.jokers.cards > 1 then
                G.jokers:unhighlight_all()
                G.E_MANAGER:add_event(Event({
                    trigger = 'before',
                    func = function()
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.jokers:shuffle('aajk')
                                play_sound('cardSlide1', 0.85)
                                return true
                            end,
                        }))
                        delay(0.15)
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.jokers:shuffle('aajk')
                                play_sound('cardSlide1', 1.15)
                                return true
                            end
                        }))
                        delay(0.15)
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.jokers:shuffle('aajk')
                                play_sound('cardSlide1', 1)
                                return true
                            end
                        }))
                        delay(0.5)
                        return true
                    end
                }))
            end
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = 0
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to $"..tostring(0), colour = G.C.MONEY})
                    return true
                end,
                extra = {
                    message = "Flip!",
                    colour = G.C.ORANGE,
                    extra = {
                        message = "Shuffle!",
                        colour = G.C.ORANGE,
                        extra = {
                            
                            func = function()
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(1).." Hands", colour = G.C.BLUE})
                                
                                G.GAME.round_resets.hands = 1
                                ease_hands_played(1 - G.GAME.current_round.hands_left)
                                
                                return true
                            end,
                            colour = G.C.GREEN,
                            extra = {
                                
                                func = function()
                                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(0).." Discards", colour = G.C.BLUE})
                                    
                                    G.GAME.round_resets.discards = 0
                                    ease_discard(0 - G.GAME.current_round.discards_left)
                                    
                                    return true
                                end,
                                colour = G.C.GREEN,
                                extra = {
                                    
                                    func = function()
                                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Play Size set to "..tostring(1), colour = G.C.BLUE})
                                        
                                        local current_play_size = (G.GAME.starting_params.play_limit or 0)
                                        local target_play_size = 1
                                        local difference = target_play_size - current_play_size
                                        SMODS.change_play_limit(difference)
                                        return true
                                    end,
                                    colour = G.C.WHITE
                                }
                            }
                        }
                    }
                }
            }
        end
    end,
    check_for_unlock = function(self,args)
        if args.type == "discard_custom" then
            local count = 0
            for i = 1, #args.cards do
                if next(evaluate_poker_hand(args.cards)["Flush Five"]) and args.cards[i].edition and args.cards[i].edition.key == "e_polychrome" and args.cards[i].seal == "thepokep_toad" then
                    count = count + 1
                end
            end
            if count == to_big(10000) then
                return true
            end
        end
        return false
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_thepokep_ohcrap" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
    	if e.config.ref_table.config.center.key == "j_thepokep_ohcrap" then
        		e.config.colour = G.C.GREEN
        		e.config.button = "use_card"
    	else
        		can_select_card_ref(e)
    	end
end