
SMODS.Joker{ --Strong Fairy
    key = "strongfairy",
    config = {
        extra = {
            hand_size_increase = '2',
            mult0 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Strong Fairy',
        ['text'] = {
            [1] = '{C:attention}+2{} Hand Size. Triggered cards give +5 Mult.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "thepokep_fairy",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["thepokep_thepokep_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                mult = 5
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(2)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-2)
    end
}