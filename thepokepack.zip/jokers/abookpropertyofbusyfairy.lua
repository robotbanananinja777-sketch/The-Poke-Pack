
SMODS.Joker{ --A Book (Property of Busy Fairy)
    key = "abookpropertyofbusyfairy",
    config = {
        extra = {
            xmult0 = 1.75,
            xchips0 = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'A Book (Property of Busy Fairy)',
        ['text'] = {
            [1] = '{X:red,C:white}x1.75{} Mult for Face Cards and {X:chips,C:white}x1.75{} Chips for Ace Cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "thepokep_fairy",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["thepokep_thepokep_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                return {
                    Xmult = 1.75
                }
            elseif context.other_card:get_id() == 14 then
                return {
                    x_chips = 1.75
                }
            end
        end
        if context.selling_self  then
            return {
                func = function()
                    
                    local created_joker = false
                    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                        created_joker = true
                        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_thepokep_ohcrap' })
                                if joker_card then
                                    
                                    
                                end
                                G.GAME.joker_buffer = 0
                                return true
                            end
                        }))
                    end
                    if created_joker then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                    end
                    return true
                end
            }
        end
    end
}