
SMODS.Joker{ --merry fairy joker!!!
    key = "merryfairyjoker",
    config = {
        extra = {
            chips0 = 100
        }
    },
    loc_txt = {
        ['name'] = 'merry fairy joker!!!',
        ['text'] = {
            [1] = '{C:chips}+100{} Chips for all cards!!! :D'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "thepokep_fairy",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["thepokep_thepokep_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                chips = 100
            }
        end
    end
}