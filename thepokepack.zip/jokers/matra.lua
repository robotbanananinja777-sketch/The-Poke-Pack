
SMODS.Joker{ --Matra
    key = "matra",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Matra',
        ['text'] = {
            [1] = 'Triggered Cards spawn Fairy Jokers,',
            [2] = 'ignores Joker Limit'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 50,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["thepokep_thepokep_jokers"] = true },
    soul_pos = {
        x = 8,
        y = 0
    },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'thepokep_fairy' })
                    if joker_card then
                        
                        
                    end
                    
                    return true
                end
            }))
            return {
                message = created_joker and localize('k_plus_joker') or nil
            }
        end
    end
}