
SMODS.Joker{ --Blue Fairy
    key = "bluefairy",
    config = {
        extra = {
            emult0 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Blue Fairy',
        ['text'] = {
            [1] = 'If at least 1 Toad Seal card',
            [2] = 'scores, you get {X:mult,C:white}^x1.5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "thepokep_fairy",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["thepokep_thepokep_jokers"] = true, ["thepokep_poke"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if playing_card.seal == "thepokep_toad" then
                        count = count + 1
                    end
                end
                return to_big(count) >= to_big(1)
            end)() then
                return {
                    e_mult = 1.5
                }
            end
        end
    end
}